/*
 *  Copyright (c) 2018-present, Evgeny Nadymov
 *
 * This source code is licensed under the GPL v.3.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import React, { PropTypes } from 'react';

class AudioTabControl extends React.Component {

    render() {

    }

}

AudioTabControl.propTypes = {};

AudioTabControl.defaultProps = {};

export default AudioTabControl;